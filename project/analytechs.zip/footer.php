<footer class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <h3 class="text-xl font-bold mb-4">Analytechs</h3>
                    <p class="text-gray-400">
                        Solutions innovantes pour votre transformation digitale
                    </p>
                </div>
                <div>
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'footer',
                        'container' => false,
                        'menu_class' => 'space-y-2',
                        'fallback_cb' => false,
                    ));
                    ?>
                </div>
                <div>
                    <h3 class="text-xl font-bold mb-4">Contact</h3>
                    <?php if ($contact_info = get_field('contact_info', 'option')): ?>
                        <address class="text-gray-400 not-italic">
                            <?php echo nl2br($contact_info); ?>
                        </address>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>