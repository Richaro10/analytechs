<?php
if (!defined('ABSPATH')) exit;

acf_add_local_field_group(array(
    'key' => 'group_hero',
    'title' => 'Hero Section',
    'fields' => array(
        array(
            'key' => 'field_hero_title',
            'label' => 'Titre',
            'name' => 'hero_title',
            'type' => 'text',
            'required' => 1,
        ),
        array(
            'key' => 'field_hero_subtitle',
            'label' => 'Sous-titre',
            'name' => 'hero_subtitle',
            'type' => 'textarea',
            'required' => 1,
        ),
        array(
            'key' => 'field_hero_cta_text',
            'label' => 'Texte du CTA',
            'name' => 'hero_cta_text',
            'type' => 'text',
        ),
        array(
            'key' => 'field_hero_cta_link',
            'label' => 'Lien du CTA',
            'name' => 'hero_cta_link',
            'type' => 'page_link',
        ),
    ),
    'location' => array(
        array(
            array(
                'param' => 'page_template',
                'operator' => '==',
                'value' => 'default',
            ),
        ),
    ),
));